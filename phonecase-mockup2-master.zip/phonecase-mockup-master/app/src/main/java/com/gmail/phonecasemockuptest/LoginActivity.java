package com.gmail.phonecasemockuptest;

import android.app.Activity;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    private EditText nLogEmail;
    private EditText nLogPassword;
    private Button nLoginBtn;
    private TextView nRegTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Initialize EditText
        nLogEmail = findViewById(R.id.LogEmail);
        nLogPassword = findViewById(R.id.LogPassword);

        // Initialize TextView
        nRegTextView = findViewById(R.id.regTextView);

        // Initialize Login Button
        nLoginBtn = findViewById(R.id.logBtn);
        nLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //User input to String (Email)
                String email = nLogEmail.getText().toString();
                //User input to String (Password)
                String password = nLogPassword.getText().toString();

                // User login authenticating method
                log_user(email, password);

                //}
            }
        });

        nRegTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regIntent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(regIntent);
            }
        });



    }

            /**** START OF USER LOGIN AUTHENTICATING ****/
    private void log_user(String email, String password) {

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful())
                {


                    Intent mainIntent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                    finish();


                }else {

                    Toast.makeText(LoginActivity.this, "Incorrect Email or password", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
            /**** END OF USER LOGIN AUTHENTICATING ****/
}
