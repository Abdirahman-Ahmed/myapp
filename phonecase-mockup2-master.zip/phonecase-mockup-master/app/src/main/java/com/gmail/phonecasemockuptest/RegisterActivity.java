package com.gmail.phonecasemockuptest;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference nDatabase;

    private EditText nRegUsername;
    private EditText nRegEmail;
    private EditText nRegPassword;
    private Button nRegBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        nRegUsername = findViewById(R.id.regUsername);
        nRegEmail = findViewById(R.id.regEmail);
        nRegPassword = findViewById(R.id.regPassword);

        nRegBtn = findViewById(R.id.regBtn);
        nRegBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //User input to String (Username)
                String username = nRegEmail.getText().toString();
                //User input to String (Email)
                String email = nRegEmail.getText().toString();
                //User input to String (Password)
                String password = nRegPassword.getText().toString();

                // User register authenticating method
                reg_user(username, email, password);
            }
        });

    }
    private void reg_user(final String username, final String email, final String password) {

        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                //Toast.makeText(Register.this, "register is successful", Toast.LENGTH_LONG).show();
                if(task.isSuccessful())
                {
                    /**** START OF WRITING DATABASE ****/
                    FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
                    String uid = current_user.getUid();
                    nDatabase = FirebaseDatabase.getInstance().getReference().child("users_account").child(uid);

                    HashMap<String, String> userMap = new HashMap<>();
                    userMap.put("name", username);
                    userMap.put("email",email);
                    userMap.put("password",password);

                    nDatabase.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if(task.isSuccessful())
                            {
                                //nRegProgressDialog.dismiss();
                                Intent mainIntent = new Intent(RegisterActivity.this, MainActivity.class);
                                startActivity(mainIntent);
                                //mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                finish();

                            }
                        }
                    });
                    /**** END OF WRITING DATABASE ****/


                    /**** START OF ERROR MESSAGE ****/
                }else{

                    Toast.makeText(RegisterActivity.this, "This account already exist", Toast.LENGTH_LONG).show();
                }
                    /*** START OF ERROR MESSAGE***/
            }
        });

    }
}
