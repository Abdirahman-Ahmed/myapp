package com.gmail.phonecasemockuptest;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class StarterActivity extends AppCompatActivity {

    private Button nRegiBtn;
    private Button nLoginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starter);


        nLoginBtn = findViewById(R.id.logiBtn);
        nLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(StarterActivity.this, LoginActivity.class);
                startActivity(loginIntent);
            }
        });

        nRegiBtn = findViewById(R.id.regiBtn);
        nRegiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regIntent = new Intent(StarterActivity.this, RegisterActivity.class);
                startActivity(regIntent);
            }
        });
    }
}
